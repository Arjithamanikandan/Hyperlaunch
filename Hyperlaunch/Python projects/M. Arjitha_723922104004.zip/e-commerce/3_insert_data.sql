USE ecommerce_db;   -- change to your DB name

CREATE TABLE numbers (
    n INT PRIMARY KEY
);

INSERT INTO numbers (n)
VALUES
(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),
(11),(12),(13),(14),(15),(16),(17),(18),(19),(20),
(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),
(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),
(41),(42),(43),(44),(45),(46),(47),(48),(49),(50);

INSERT INTO numbers (n)
SELECT n + 50 FROM numbers WHERE n <= 150;

INSERT INTO category (category_name)
SELECT CONCAT('Category_', n)
FROM numbers;

INSERT INTO customer (first_name, last_name, email, phone, address)
SELECT
    CONCAT('First_', n),
    CONCAT('Last_', n),
    CONCAT('user', n, '@example.com'),
    CONCAT('90000', LPAD(n, 5, '0')),
    CONCAT('Address ', n)
FROM numbers;

INSERT INTO product (product_name, category_id, price, stock_quantity)
SELECT
    CONCAT('Product_', n),
    n,
    ROUND(RAND() * 50000 + 500, 2),
    FLOOR(RAND() * 200 + 10)
FROM numbers;

SHOW CREATE TABLE product_details;
SHOW CREATE TABLE purchase;
SHOW CREATE TABLE payment;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE payment;
TRUNCATE TABLE purchase;
TRUNCATE TABLE product_details;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO product_details (product_id, description, brand, warranty)
SELECT
    product_id,
    CONCAT('Description for product ', product_id),
    CONCAT('Brand_', product_id % 10),
    IF(product_id % 2 = 0, '1 Year', 'No Warranty')
FROM product;

INSERT INTO purchase (customer_id, product_id, purchase_date, quantity, total_amount)
SELECT
    c.customer_id,
    p.product_id,
    CURDATE(),
    1,
    p.price
FROM customer c
JOIN product p
ON c.customer_id = p.product_id
LIMIT 200;

INSERT INTO payment (purchase_id, payment_date, amount_paid, payment_mode)
SELECT
    purchase_id,
    purchase_date,
    total_amount,
    'UPI'
FROM purchase;

SELECT COUNT(*) FROM product_details; -- 200
SELECT COUNT(*) FROM purchase;        -- 200
SELECT COUNT(*) FROM payment;         -- 200






