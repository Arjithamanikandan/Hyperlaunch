def exam_result(name,score, questions, options, correct_answers, user_answers, total_time):

    total = len(questions)
    percentage = (score / total) * 100

    print("----- SCORE CARD -----")
    print("Student Name :", name)
    print("Total Questions :", total)
    print("Correct Answers :", score)
    print("Wrong Answers:", total - score)
    print("Percentage :", percentage, "%")
    print("Time Taken :", total_time, "seconds")
    if percentage >= 80:
        print("Grade : A+")
        print("Result : DISTINCTION")
    elif percentage >= 60:
        print("Grade : A")
        print("Result : FIRST CLASS")
    elif percentage >= 40:
        print("Grade : B")
        print("Result : PASS")
    else:
        print("Grade : C")
        print("Result : FAIL")

    print("\n----- REVIEW WRONG ANSWERS -----")

    for i in range(total):
        if user_answers[i] != correct_answers[i]:
            print(questions[i])
            print("Your Answer :", options[i][user_answers[i] - 1])
            print("Correct Answer :", options[i][correct_answers[i] - 1])
            print()