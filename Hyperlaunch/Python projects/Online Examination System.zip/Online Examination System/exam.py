import time

def start_exam():
    questions = [
        "1. What is the capital of France?",
        "2. What is 2 + 2?",
        "3. What is the largest planet in our solar system?",
        "4. Who wrote 'Romeo and Juliet'?",
        "5. What is the boiling point of water?"
    ]
    
    options = [
        ["1) Berlin", "2) Madrid", "3) Paris", "4) Rome"],
        ["1) 3", "2) 7", "3) 5", "4) 4"],
        ["1) Earth", "2) Jupiter", "3) Saturn", "4) Mars"],
        ["1) Charles Dickens", "2) William Shakespeare", "3) Mark Twain", "4) Jane Austen"],
        ["1) 90°C", "2) 110°C", "3) 100°C", "4) 120°C"]
    ]

    correct_answers = [3, 4, 2, 2, 3]  
    user_answers = []
    score = 0
    
    print("-----Starting the Exam-----")
    start_time = time.time()
    
    for i in range(len(questions)):
        print(questions[i])
        for opt in options[i]:
            print(opt)

        while True:
            try:
                answer = int(input("Enter your answer from numbers(1-4): "))
                if 1 <= answer <= 4:
                    user_answers.append(answer)
                    if answer == correct_answers[i]:
                        score += 1
                    break
                else:
                    print("Enter a number between 1 and 4.")
            except ValueError:
                print("Invalid input. Please enter a number between 1 and 4.")
        
        print()
        
    end_time = time.time()
    total_time = round(end_time - start_time, 2)
    
    return score, questions, options, correct_answers, user_answers, total_time