from login import login_users
from exam import start_exam
from result import exam_result  

def instructions():
    print("-----Exam Instructions-----")
    print("1. The exam consists of 5 multiple-choice questions.")
    print("2. Each question has four options: a, b, c, and d.")
    print("3. Select the correct option by typing a, b, c, or d.")
    print("4. There is no negative marking for wrong answers.")
    print("5. Try to answer all questions to the best of your ability.")
    print("6. Your performance will be graded based on your score.\n")

student_name = login_users()
while True:
    instructions()
    score, questions, options, correct_answers, user_answers, total_time = start_exam()
    exam_result(student_name, score, questions, options, correct_answers, user_answers, total_time)

    retry = input("Do you want to retake the exam? (yes/no): ").strip().lower()
    if retry != 'yes':
        print("Thank you for participating in the exam. Goodbye!")
        break