def login_users():
    users = ['Arjitha','Ragavi','Harshu','Karthick']
    attempts = 3

    while attempts > 0:
        print("-----Student Login-----")
        username = input("Enter your username: ")

        if username in users:
            print("Login successful!!\n")
            return username
        else:
            attempts -= 1
            print("Invalid username!!")
            print("Attempts left:", attempts, "\n")

    print("All attempts exhausted. Acess denied")
    exit()